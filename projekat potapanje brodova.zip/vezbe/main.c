#include <stdio.h>
#include <stdlib.h>
#include<windows.h>
#include<string.h>

void SetBackgraundColor(int BackC)
{
    CONSOLE_SCREEN_BUFFER_INFO csbf;
    WORD wColor=((BackC & 0x0f) << 4)+ (csbf.wAttributes & 0x0f);
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),wColor);
    return;


}
void SetColor(int ForgC)
{
    WORD wColor;

    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);

    //we use csbi for the wAttributes word.
    CONSOLE_SCREEN_BUFFER_INFO csbi;

    if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
    {
        //Mask out all but the background attribute
        //, and add in the foreground color
        wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
        SetConsoleTextAttribute(hStdOut, wColor);
    }
}


typedef struct board
{
    int isselected;
    int isSelectedByEnemy;
    int isDest;
    char character[3];


} Board;
void clear()
{
    system("cls");
}
void fill(Board tabla[11][11])
{


    strcpy(tabla[0][1].character, "1");
    strcpy(tabla[0][2].character, "2");
    strcpy(tabla[0][3].character, "3");
    strcpy(tabla[0][4].character, "4");
    strcpy(tabla[0][5].character, "5");
    strcpy(tabla[0][6].character, "6");
    strcpy(tabla[0][7].character, "7");
    strcpy(tabla[0][8].character, "8");
    strcpy(tabla[0][9].character, "9");
    strcpy(tabla[0][10].character,"10");

    strcpy(tabla[0][0].character, "/");


    strcpy(tabla[1][0].character, "A");
    strcpy(tabla[2][0].character, "B");
    strcpy(tabla[3][0].character, "C");
    strcpy(tabla[4][0].character, "D");
    strcpy(tabla[5][0].character, "E");
    strcpy(tabla[6][0].character, "F");
    strcpy(tabla[7][0].character, "G");
    strcpy(tabla[8][0].character, "H");
    strcpy(tabla[9][0].character, "I");
    strcpy(tabla[10][0].character, "J");

    for(int i=0;i<11;i++)
    {


        for(int j=0;j<11;j++)
        {tabla[i][j].isselected=0;
            if(i!=0 && j!=0)
          {strcpy(tabla[i][j].character,tabla[0][j].character);
          strcat(tabla[i][j].character,tabla[i][0].character);




          }

        }
    }
    tabla[10][1].isselected=0;



    return tabla;
}
void board(Board tabla[11][11])
{
    int j,i;

    char character[3];



    for( j=0; j<11; j++)
    {
        for( i=0; i<11; i++)
        {
            SetBackgraundColor(7);
            if(i==0 || j==0)
            {
                SetBackgraundColor(2);



                printf(" %s ",tabla[j][i].character);

            }
            else if(i!=0 && j!=0)
            {
                SetBackgraundColor(3);
                printf(" %s%s",tabla[j][0].character,tabla[0][i].character);



            }





        }
        printf("\n");
    }
}
void boardSelected(Board tabla[11][11],int n,int m ,int k,int r)
{
    int j,i;



    for( j=0; j<11; j++)
    {
        for( i=0; i<11; i++)
        {

            SetBackgraundColor(7);
            if(i==0 || j==0)
            {
                SetBackgraundColor(2);



                printf("  %s  ",tabla[j][i].character);

            }
            else if(i!=0 && j!=0)
            {
                /*


                if( (n==i && m==j) || (tabla[i][j].isselected==1)){


                SetBackgraundColor(4);
               // printf(" %s%s",tabla[j][0].character,tabla[0][i].character);
               for(int z=1;z<k;z++)
                printf(" %s  ",tabla[j][i+z].character);
                }else {
                    SetBackgraundColor(3);
                //printf(" %s%s",tabla[j][0].character,tabla[0][i].character);
                        printf(" %s  ",tabla[j][i].character);


                        1 2 3 4 5 6 7 8 9  10

                                k+i     n
                }
                */



                 SetBackgraundColor(3);//plava
                 if(r==0){
                 if((tabla[j][i].isselected==1) || (n==i && m==j)  || ( (n>=i && i>=n-k ) && m==j))
                        SetBackgraundColor(4);//crvena
                     printf(" %s  ",tabla[j][i].character);
                 }else{

                 if((tabla[j][i].isselected==1) || (n==i && m==j)  || ( (m>=j && j>=m-k ) && n==i))
                        SetBackgraundColor(4);//crvena
                     printf(" %s  ",tabla[j][i].character);
                 }
                  SetBackgraundColor(0);





            }





        }
        printf("\n");
    }

}
void ispisMenia(int odluka)
{
    SetColor(10);
    printf("\n************************************************************");
    printf("\n-------------------------WELCOME----------------------------");
    printf("\n************************************************************\n");
    printf("                                                            \n");
    printf("                                                            \n");
    printf("                                                            \n");
    if(odluka==0)
    {
        SetColor(0);
        SetBackgraundColor(10);

        printf("                     1:Player VS PLayer                     \n");
        SetBackgraundColor(0);
        SetColor(10);
    }
    else
    {
        printf("                     1:Player VS PLayer                     \n");
    }
    printf("                                                            \n");
    if(odluka==1)
    {
        SetColor(0);
        SetBackgraundColor(10);
        printf("                     2:Player VS Bot                        \n");
        SetBackgraundColor(0);
             SetColor(10);
    }
    else
    {
        printf("                     2:Player VS Bot                        \n");
    }
    printf("                                                            \n");
    if(odluka==2)
    {
        SetColor(0);
        SetBackgraundColor(10);
        printf("                     3:Quit the game                        \n");
        SetBackgraundColor(0);
          SetColor(10);
    }
    else
    {
        printf("                     3:Quit the game                        \n");

    }
    printf("                                                            \n");
    /*
    switch(getch()) {
    case 65:    // key up
        break;
    case 66:    // key down
        break;
    case 67:    // key right
        break;
    case 68:    // key left
        break;
    }
    */


}
void tableSelectedByEnemy(Board tabla[11][11],int n,int m ,int k,int r)
{
    int j,i;



    for( j=0; j<11; j++)
    {
        for( i=0; i<11; i++)
        {

            SetBackgraundColor(7);
            if(i==0 || j==0)
            {
                SetBackgraundColor(2);



                printf("  %s  ",tabla[j][i].character);

            }
            else if(i!=0 && j!=0)
            {




                 SetBackgraundColor(3);
                 if((tabla[j][i].isSelectedByEnemy==1) || (n==i && m==j)  || (tabla[j][i].isDest==1)){
                 if(tabla[j][i].isDest==1){
                        SetBackgraundColor(60);
                 }else{
                     SetBackgraundColor(77);
                 }
                 }

                     printf(" %s  ",tabla[j][i].character);
                     SetBackgraundColor(0);







            }





        }
        printf("\n");
    }

}
void PvP( Board tabla[11][11],Board tabla2[11][11])
{int i=1,j=1,a;
int odluka=0;
int r=1,k;
for(int z=0;z<11;z++)
{
    for(int t=0;t<11;t++)
    {
        tabla[z][t].isDest=0;
        tabla[z][t].isSelectedByEnemy=0;
                tabla2[z][t].isDest=0;
        tabla2[z][t].isSelectedByEnemy=0;
    }
}
for( k=0;k<4;k++)
{
    odluka=0;




    do{
             clear();

             boardSelected(tabla,j,i,k,r);



        char c=getch();
    /*    SetColor(3);
        printf(" \n %d \n ",r);*/
                switch(c) {
                case 114:
                    if(r==1){
                    r=0;
                    }else{
                    r=1;
                    }
                     clear();

                     boardSelected(tabla,j,i,k,r);

                    break;
    case 13:
         clear();
         odluka=1;
         int z=i;
         if(r==1){
         for(int o=0;o<=k;o++)
              tabla[i-o][j].isselected=1;
            // tabla[i][j-o].isselected=1;
         }
         if(r==0){
            for(int o=0;o<=k;o++)
             tabla[i][j-o].isselected=1;

         }






            boardSelected(tabla,j,i,k,r);





        break;

        case 72:
            clear();
            if(i+k!=1)
            i--;

            boardSelected(tabla,j,i,k,r);

            SetBackgraundColor(0);


            break;
     case 75:
                  clear();
            if(j!=1)
            j--;

              boardSelected(tabla,j,i,k,r);



                      SetBackgraundColor(0);


            break;
        case 77:
            clear();
            if(j!=10)
            j++;

              boardSelected(tabla,j,i,k,r);


                      SetBackgraundColor(0);

            break;
        case 80:
            clear();
            if(i!=10)
            i++;

              boardSelected(tabla,j,i,k,r);
     SetBackgraundColor(0);

            break;
                }



 } while(odluka!=1);
}
clear();
printf("neka 2 osoba unese njihove brodove ");
i=1;
j=1;
for( k=0;k<4;k++)
{
    odluka=0;




    do{
             clear();

             boardSelected(tabla2,j,i,k,r);



        char c=getch();
    /*    SetColor(3);
        printf(" \n %d \n ",r);*/
                switch(c) {
                case 114:
                    if(r==1){
                    r=0;
                    }else{
                    r=1;
                    }
                     clear();

                     boardSelected(tabla2,j,i,k,r);

                    break;
    case 13:
         clear();
         odluka=1;
         int z=i;
         if(r==1){
         for(int o=0;o<=k;o++)
              tabla2[i-o][j].isselected=1;
            // tabla[i][j-o].isselected=1;
         }
         if(r==0){
            for(int o=0;o<=k;o++)
             tabla2[i][j-o].isselected=1;

         }






            boardSelected(tabla2,j,i,k,r);





        break;

        case 72:
            clear();
            if(i+k!=1)
            i--;

            boardSelected(tabla2,j,i,k,r);

            SetBackgraundColor(0);


            break;
     case 75:
                  clear();
            if(j!=1)
            j--;

              boardSelected(tabla2,j,i,k,r);



                      SetBackgraundColor(0);


            break;
        case 77:
            clear();
            if(j!=10)
            j++;

              boardSelected(tabla2,j,i,k,r);


                      SetBackgraundColor(0);

            break;
        case 80:
            clear();
            if(i!=10)
            i++;

              boardSelected(tabla2,j,i,k,r);
     SetBackgraundColor(0);

            break;
                }



 } while(odluka!=1);
}
//gadjanje brodova
printf("sada ce te napadati tudje brodove ");
i=1;
j=1;


    odluka=0;



//napad  jednog
do{

 odluka=0;
    do{
             clear();


             tableSelectedByEnemy(tabla2,j,i,k,r);




        char c=getch();
    /*    SetColor(3);
        printf(" \n %d \n ",r);*/
                switch(c) {



    case 13:
         clear();




              tabla2[i][j].isDest=1;
        if(tabla2[i][j].isDest==1 && tabla2[i][j].isselected==1)
        {
          odluka=0;
        }else{
         odluka=1;
        }








           tableSelectedByEnemy(tabla2,j,i,k,r);





        break;

        case 72:
            clear();
            if(i+k!=1)
            i--;

            tableSelectedByEnemy(tabla2,j,i,k,r);

            SetBackgraundColor(0);


            break;
     case 75:
                  clear();
            if(j!=1)
            j--;

            tableSelectedByEnemy(tabla2,j,i,k,r);



                      SetBackgraundColor(0);


            break;
        case 77:
            clear();
            if(j!=10)
            j++;

             tableSelectedByEnemy(tabla2,j,i,k,r);


                      SetBackgraundColor(0);

            break;
        case 80:
            clear();
            if(i!=10)
            i++;

              tableSelectedByEnemy(tabla2,j,i,k,r);
     SetBackgraundColor(0);

            break;
                }



 } while(odluka!=1);
 //napad drugog
  odluka=0;
     do{
             clear();

            tableSelectedByEnemy(tabla,j,i,k,r);


         fflush(stdin);
       char c=getch();
    /*    SetColor(3);
        printf(" \n %d \n ",r);*/
                switch(c) {



    case 13:
         clear();




              tabla[i][j].isDest=1;
        if(tabla2[i][j].isDest==1 && tabla2[i][j].isselected==1){
         odluka=0;


         }else{
         odluka=1;
         }








             tableSelectedByEnemy(tabla,j,i,k,r);





        break;

        case 72:
            clear();
            if(i+k!=1)
            i--;
 tableSelectedByEnemy(tabla,j,i,k,r);

            SetBackgraundColor(0);


            break;
     case 75:
                  clear();
            if(j!=1)
            j--;

            tableSelectedByEnemy(tabla,j,i,k,r);



                      SetBackgraundColor(0);


            break;
        case 77:
            clear();
            if(j!=10)
            j++;
 tableSelectedByEnemy(tabla,j,i,k,r);


                      SetBackgraundColor(0);

            break;
        case 80:
            clear();
            if(i!=10)
            i++;

              tableSelectedByEnemy(tabla,j,i,k,r);
     SetBackgraundColor(0);

            break;
                }



 } while(odluka!=1);
 a=vratibr(tabla,tabla2);


}while(a==1);
clear();

if(a==1)
{
    SetColor(10);
    printf("                                                            \n");
    printf("                       drugi igrac  je pobedio              \n");
    printf("                                                            \n");
    char b=getchar();
    return 0;
}
if(a==2)
{
    SetColor(10);
    printf("                                                            \n");
    printf("                prvi igrac je pobedio                       \n");
    printf("                                                            \n");
     char b=getchar();
    return 0;
}


}
int vratibr(Board tabla[11][11],Board tabla2[11][11])
{int count=0,count2=0;
    for(int i=0;i<11;i++)
    {
        for(int j=0;j<11;j++)
        {
            if(tabla[i][j].isselected==1 && tabla[i][j].isDest==1)
            {
                count++;
            }
           if(tabla2[i][j].isselected==1 && tabla2[i][j].isDest==1)
            {
                count2++;
            }


        }
    }


    if(10-count==0)
    {
       return  1;
    }
    if(10-count2==0)
    {
        return  2;
    }
    if(count>0 && count2>0)
    {
        return 1;
    }

}
void PvE(Board tabla[11][11],Board tabla2[11][11])
{
    int i=1,j=1,a;
int odluka=0;
int r=1,k;
for(int z=0;z<11;z++)
{
    for(int t=0;t<11;t++)
    {
        tabla[z][t].isDest=0;
        tabla[z][t].isSelectedByEnemy=0;
                tabla2[z][t].isDest=0;
        tabla2[z][t].isSelectedByEnemy=0;
    }
}
for( k=0;k<4;k++)
{
    odluka=0;




    do{
             clear();

             boardSelected(tabla,j,i,k,r);



        char c=getch();
    /*    SetColor(3);
        printf(" \n %d \n ",r);*/
                switch(c) {
                case 114:
                    if(r==1){
                    r=0;
                    }else{
                    r=1;
                    }
                     clear();

                     boardSelected(tabla,j,i,k,r);

                    break;
    case 13:
         clear();
         odluka=1;
         int z=i;
         if(r==1){
         for(int o=0;o<=k;o++)
              tabla[i-o][j].isselected=1;
            // tabla[i][j-o].isselected=1;
         }
         if(r==0){
            for(int o=0;o<=k;o++)
             tabla[i][j-o].isselected=1;

         }






            boardSelected(tabla,j,i,k,r);





        break;

        case 72:
            clear();
            if(i+k!=1)
            i--;

            boardSelected(tabla,j,i,k,r);

            SetBackgraundColor(0);


            break;
     case 75:
                  clear();
            if(j!=1)
            j--;

              boardSelected(tabla,j,i,k,r);



                      SetBackgraundColor(0);


            break;
        case 77:
            clear();
            if(j!=10)
            j++;

              boardSelected(tabla,j,i,k,r);


                      SetBackgraundColor(0);

            break;
        case 80:
            clear();
            if(i!=10)
            i++;

              boardSelected(tabla,j,i,k,r);
     SetBackgraundColor(0);

            break;
                }



 } while(odluka!=1);
}
clear();

tabla2[1][1].isselected=1;//1
tabla2[1][2].isselected=1;//2
tabla2[2][2].isselected=1;//3
tabla2[1][3].isselected=1;//4
tabla2[2][3].isselected=1;//5
tabla2[3][3].isselected=1;//6
tabla2[1][4].isselected=1;//7
tabla2[2][4].isselected=1;//8
tabla2[3][4].isselected=1;//9
tabla2[4][4].isselected=1;//10





//gadjanje brodova
printf("sada ce te napadati tudje brodove ");
i=1;
j=1;


    odluka=0;



//napad  jednog
do{

 odluka=0;
    do{
             clear();


             tableSelectedByEnemy(tabla2,j,i,k,r);




        char c=getch();
    /*    SetColor(3);
        printf(" \n %d \n ",r);*/
                switch(c) {



    case 13:
         clear();
         odluka=1;



              tabla2[i][j].isDest=1;








           tableSelectedByEnemy(tabla2,j,i,k,r);





        break;

        case 72:
            clear();
            if(i+k!=1)
            i--;

            tableSelectedByEnemy(tabla2,j,i,k,r);

            SetBackgraundColor(0);


            break;
     case 75:
                  clear();
            if(j!=1)
            j--;

            tableSelectedByEnemy(tabla2,j,i,k,r);



                      SetBackgraundColor(0);


            break;
        case 77:
            clear();
            if(j!=10)
            j++;

             tableSelectedByEnemy(tabla2,j,i,k,r);


                      SetBackgraundColor(0);

            break;
        case 80:
            clear();
            if(i!=10)
            i++;

              tableSelectedByEnemy(tabla2,j,i,k,r);
     SetBackgraundColor(0);

            break;
                }



 } while(odluka!=1);
 //napad drugog
  odluka=0;
  int row=1;
  int collum=1;

             clear();
             if(row==10)
             {
                 row=1;
                 if(collum==10){
                    collum=1;
                 }
                 collum++;
             }else {
             row++;
             }

              tabla2[row][collum].isDest=1;







 a=vratibr(tabla,tabla2);
 SetColor(63);
 printf(" \n %d \n ",a);
 char d=getchar();
}while(a==1);
clear();

if(a==1)
{
    printf("                                                            \n");
    printf("                       drugi igrac  je pobedio              \n");
    printf("                                                            \n");
    char b=getchar();
    return 0;
}
if(a==2)
{
    printf("                                                            \n");
    printf("                prvi igrac je pobedio                       \n");
    printf("                                                            \n");
     char b=getchar();
    return 0;
}


}


int main()
{
    int odluka,odlukaArow=0;
     Board tabla[11][11];
      Board tabla2[11][11];
      fill(&tabla);

      fill(&tabla2);




 ispisMenia(odlukaArow);

    do
    {
       // ispisMenia(odlukaArow);


while(1){
char c=getch();
    switch(c) {  // the real value
    case 13:
        printf(" %d ",odlukaArow);
        if(odlukaArow==0)
        {
            PvP(tabla,tabla2);


        }else if(odlukaArow==1)
        {
            PvE(tabla,tabla2);

        }else if(odlukaArow==2)
        {
              printf("                                                            \n");
              printf("                    hvala na igri                           \n");
              printf("                                                            \n");
            return 0;
        }


        break;

        case 72:
            clear();
            if(odlukaArow!=0)
            odlukaArow--;
             ispisMenia(odlukaArow);

            // code for arrow up
            break;
    /*    case 75:
                      printf("\n left");
            // code for arrow down
            break;
        case 77:
            // code for arrow right
            break;*/
        case 80:
            clear();
            if(odlukaArow!=2)
            odlukaArow++;
             ispisMenia(odlukaArow);
            // code for arrow left
            break;

    }
}





/*
        system("color 1");
        SetColor(0);
        SetBackgraundColor(10);
        ispisMenia(odlukaArow);




        board();

        scanf("%d",&odluka);
        system("cls");
        */



    }
    while(odluka!=0);



    return 0;
}
